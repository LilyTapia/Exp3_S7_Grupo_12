package controlador;

import bd.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Movie;

public class Registro {

    public boolean agregar(Movie movie) {

        try {
            Conexion conexion1 = new Conexion();
            Connection cnx = conexion1.obtenerConexion();

            String query = "INSERT INTO MOVIE (id_movie, titulo, director, anio, duracion, genero) VALUES (?,?,?,?,?,?)";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setString(1, movie.getid_movie());
            stmt.setString(2, movie.gettitulo());
            stmt.setString(3, movie.getdirector());
            stmt.setInt(4, movie.getanio());
            stmt.setInt(5, movie.duracion());
            stmt.setString(6, movie.getgenero());

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Error SQL al agregar pelicula" + e.getMessage());
            return false;
        } catch (Exception e) {
            System.out.println("Error al agregar pelicula" + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id_movie) {
        try {
            Conexion conexion1 = new Conexion();
            Connection cnx = conexion1.obtenerConexion();

            String query = "DELETE FROM movie WHERE id_movie?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setInt(1, id_movie);

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Error SQL al eliminar pelicula" + e.getMessage());
            return false;
        } catch (Exception e) {
            System.out.println("Error al eliminar pelicula" + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Movie movie) {
        try {
            Conexion conexion1 = new Conexion();
            Connection cnx = conexion1.obtenerConexion();

            String query = "UPDATE movie set id_movie = ?, titulo = ?, director = ?, anio = ?, duracion = ?, genero= ? WHERE idmovie=?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            stmt.setString(1, movie.getid_movie());
            stmt.setString(2, movie.gettitulo());
            stmt.setString(3, movie.getdirector());
            stmt.setInt(4, movie.getanio());
            stmt.setInt(5, movie.duracion());
            stmt.setString(6, movie.getgenero());

            stmt.executeUpdate();
            stmt.close();
            cnx.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Error SQL al actualizar pelicula" + e.getMessage());
            return false;
        } catch (Exception e) {
            System.out.println("Error al actualizar pelicula" + e.getMessage());
            return false;
        }
    }

    public Movie buscarPorId(int id_movie) {
        Movie movie = new Movie();

        try {
            Conexion conexion1 = new Conexion();
            Connection cnx = conexion1.obtenerConexion();

            String query = "SELECT id_movie, titulo, director, anio, duracion, genero  FROM movie WHERE idmovie=?";
            PreparedStatement stmt = cnx.prepareStatement(query);
            int id_Movie = 0;
            stmt.setInt(1, id_Movie);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                movie.setId_Movie(rs.getInt("id_movie"));
                movie.setTitulo(rs.getString("titulo"));
                movie.setdirector(rs.getString("director"));
                movie.setanio(rs.getInt("anio"));
                movie.setduracion(rs.getInt("duracion"));
                movie.setgenero(rs.getString("genero"));

            }

            rs.close();
            stmt.close();
            cnx.close();
        } catch (SQLException e) {
            System.out.println("Error SQL al peliculas libro por id" + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error al listar peliculas por id" + e.getMessage());
        }
        return movie;
    }

    public List<Movie> buscarTodos() {
        List<Movie> lista = new ArrayList<Movie>();

        try {
            Conexion conexion1 = new Conexion();
            Connection cnx = conexion1.obtenerConexion();

            String query = "SELECT id_movie, titulo, director, anio, duracion, genero FROM movie order by titulo";
            PreparedStatement stmt = cnx.prepareStatement(query);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Movie movie = new Movie();
                movie.setId_Movie(rs.getInt("id_movie"));
                movie.settitulo(rs.getString("titulo"));
                movie.setdirector(rs.getString("director"));
                movie.setanio(rs.getInt("anio"));
                movie.setduracion(rs.getInt("duracion"));
                movie.setgenero(rs.getString("genero"));

                lista.add(movie);
            }
            rs.close();
            stmt.close();
            cnx.close();
        } catch (SQLException e) {
            System.out.println("Error SQL al listar peliculas" + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error al listar peliculas" + e.getMessage());
        }
        return lista;
    }
}
